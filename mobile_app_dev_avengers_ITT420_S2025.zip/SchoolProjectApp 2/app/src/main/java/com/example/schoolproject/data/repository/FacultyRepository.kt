package com.example.schoolproject.data.repository

import com.example.schoolproject.data.database.DatabaseHelper
import com.example.schoolproject.data.model.Faculty


class FacultyRepository(private val dbHelper: DatabaseHelper) {
    fun insert(faculty: Faculty): Long = dbHelper.insertFaculty(faculty)
    fun insertAll(faculties: List<Faculty>) = dbHelper.insertAllFaculty(faculties)
    fun update(faculty: Faculty) = dbHelper.updateFaculty(faculty)
    fun deleteById(facultyId: Int) = dbHelper.deleteFaculty(facultyId)
    fun getFacultyById(facultyId: Int): Faculty? = dbHelper.getFacultyById(facultyId)
    fun getAllFaculty(): List<Faculty> = dbHelper.getAllFaculty()
    fun isFacultyTableEmpty():Boolean = dbHelper.isFacultyTableEmpty()
}
