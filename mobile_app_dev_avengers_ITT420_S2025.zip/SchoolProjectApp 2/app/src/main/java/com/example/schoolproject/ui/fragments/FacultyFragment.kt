package com.example.schoolproject.ui.fragments

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.provider.Settings
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.fragment.app.viewModels
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.bumptech.glide.Glide
import com.example.bookproject.utils.makeGone
import com.example.bookproject.utils.makeVisible
import com.example.movieapp.view.base.BaseFragment
import com.example.schoolproject.R
import com.example.schoolproject.data.model.Faculty
import com.example.schoolproject.data.viewmodel.FacultyViewModel
import com.example.schoolproject.databinding.FacultyBottomSheetLayoutBinding
import com.example.schoolproject.databinding.FragmentFacultyBinding
import com.example.schoolproject.ui.adapters.FacultyAdapter
import com.example.schoolproject.utils.CallBacks
import com.example.schoolproject.utils.Utils
import com.google.android.material.bottomsheet.BottomSheetDialog
import java.io.File

class FacultyFragment : BaseFragment() {
    private lateinit var binding: FragmentFacultyBinding
    private lateinit var facultyAdapter: FacultyAdapter
    private val facultyViewModel: FacultyViewModel by viewModels {
        ViewModelProvider.AndroidViewModelFactory.getInstance(requireActivity().application)
    }
    private var selectedImageUri: Uri? = null
    private var selectedImagePath: String? = null
    private var bottomSheetDialog:BottomSheetDialog?= null
    var bottomSheetBinding:FacultyBottomSheetLayoutBinding ?= null

    private val selectImageLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            selectedImageUri = result.data?.data
            selectedImageUri?.let { uri ->
                bottomSheetBinding?.selectedImageView?.setImageURI(uri)
                selectedImagePath = getRealPathFromURI(uri)
            }
        }
    }
    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val granted = permissions.entries.all { it.value }
        if (granted) {
//            openImagePicker()
        } else {
            Utils.displaySimpleAlertDialog(mContext, "Permission Denied",
                "Your app needs permission to read images from the storage",
                "Open Settings", "Cancel", object :CallBacks.SimpleAlertDialog{
                    override fun positiveButtonClick(text: String) {
                        openAppSettings()
                    }

                    override fun negativeButtonClick() {
                        Toast.makeText(mContext, "Permission denied", Toast.LENGTH_SHORT).show()
                    }

                })
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        binding = FragmentFacultyBinding.inflate(layoutInflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        with(binding) {
            requestPermissionsSafely()
            //setting faculty adapter
            facultyAdapter = FacultyAdapter(mContext, object : CallBacks.FacultyClick {
                override fun facultySelected(facultyId: Int) {
                    facultyViewModel.getFacultyById(facultyId).observe(viewLifecycleOwner) { faculty ->
                        faculty?.let {
                            if(hasImagesPermission(mContext)){
                                openButtonSheetDialog(it)
                            }else{
                                requestPermissionsSafely()
                            }
                        }
                    }
                }

                override fun facultyDeleted(facultyId: Int) {
                    facultyViewModel.deleteById(facultyId)
                }
            })

            binding.rvFaculty.apply {
                layoutManager = LinearLayoutManager(mContext)
                adapter = facultyAdapter
            }

            facultyViewModel.getAllFaculty().observe(viewLifecycleOwner) { facultys ->
                progressBar.makeGone()
                if (facultys.isEmpty()) {
                    binding.emptyLayout.root.makeVisible()
                    binding.rvFaculty.makeGone()
                } else {
                    binding.emptyLayout.root.makeGone()
                    binding.rvFaculty.makeVisible()
                }
                facultyAdapter.submitList(facultys)
            }

            binding.btnAddFaculty.setOnClickListener {
                if(hasImagesPermission(mContext)){
                    openButtonSheetDialog(null)
                }else{
                  requestPermissionsSafely()
                }
            }
        }
    }
    private fun openButtonSheetDialog(faculty: Faculty?) {
       bottomSheetDialog = BottomSheetDialog(mContext)
        bottomSheetBinding = FacultyBottomSheetLayoutBinding.inflate(layoutInflater)
        bottomSheetDialog?.let { dialog->
            bottomSheetBinding?.let { dialogBindng->
                dialog.setContentView(dialogBindng.root)
                with(dialogBindng){
                    faculty?.let { it->
                        tvBottomSheetTitle.text = getString(R.string.update_this_faculty_member)
                        txtFacultyName.setText(it.name)
                        txtEmail.setText(it.email)
                        txtTelephone.setText(it.telephone)
                        Glide.with(mContext).load(it.photoPath).into(selectedImageView)
                        btnAddUpdate.text = getString(R.string.update)
                    }
                    ivClose.setOnClickListener {
                        dialog.dismiss()
                    }
                    selectImageButton.setOnClickListener {
                        val intent = Intent(Intent.ACTION_GET_CONTENT)
                        intent.type = "image/*"
                        selectImageLauncher.launch(intent)
                    }
                    btnAddUpdate.setOnClickListener {
                        if (txtFacultyName.text.isNotBlank() && txtEmail.text.isNotBlank() &&
                            txtTelephone.text.isNotBlank() && selectedImagePath != null) {
                            val name = txtFacultyName.text.toString().trim()
                            val email = txtEmail.text.toString().trim()
                            val telephone = txtTelephone.text.toString().trim()
                            if(faculty == null){
                                facultyViewModel.insert(
                                    Faculty(
                                        name = name,
                                        telephone = telephone,
                                        email = email,
                                        photoPath = selectedImagePath!!
                                    )
                                )
                            }else{
                                facultyViewModel.update(
                                    Faculty(
                                        facultyId = faculty.facultyId,
                                        name = name,
                                        email = email,
                                        telephone = telephone,
                                        photoPath = selectedImagePath!!,
                                        isInitial = faculty.isInitial
                                    )
                                )
                            }
                            dialog.dismiss()
                        }else {
                            Toast.makeText(mContext, "All fields are required", Toast.LENGTH_SHORT)
                                .show()
                        }
                    }
                }
                dialog.show()
            }
        }
    }
    private fun getRealPathFromURI(uri: Uri): String {
        var fileName = "temp_file"
        mContext.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (cursor.moveToFirst()) {
                fileName = cursor.getString(nameIndex)
            }
        }

        val file = File(mContext.cacheDir, fileName)
        mContext.contentResolver.openInputStream(uri)?.use { input ->
            file.outputStream().use { output ->
                input.copyTo(output)
            }
        }
        return file.absolutePath
    }
    private fun requestPermissionsSafely() {
        val permissions = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
            arrayOf(android.Manifest.permission.READ_MEDIA_IMAGES)
        } else {
            arrayOf(android.Manifest.permission.READ_EXTERNAL_STORAGE)
        }
        requestPermissionLauncher.launch(permissions)
    }
    private fun openAppSettings() {
        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
            data = Uri.fromParts("package", mContext.packageName, null)
        }
        startActivity(intent)
    }
    fun hasImagesPermission(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(
                context,
                android.Manifest.permission.READ_MEDIA_IMAGES
            ) == PackageManager.PERMISSION_GRANTED
        } else {
            ContextCompat.checkSelfPermission(
                context,
                android.Manifest.permission.READ_EXTERNAL_STORAGE
            ) == PackageManager.PERMISSION_GRANTED
        }
    }
}
