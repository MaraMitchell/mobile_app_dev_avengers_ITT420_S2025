package com.example.schoolproject.ui.adapters
import android.app.Activity
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.schoolproject.R
import com.example.schoolproject.utils.CallBacks
import com.example.schoolproject.data.model.Course
import com.example.schoolproject.utils.Utils
import com.example.schoolproject.databinding.CourseItemLayoutBinding

class CourseAdapter(val context:Activity, val listener: CallBacks.CourseClick):ListAdapter<Course,RecyclerView.ViewHolder>(
    CourseComparator
){
     override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
       return CourseViewHolder(CourseItemLayoutBinding.inflate
           (context.layoutInflater,parent,false))
     }
     override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
       holder as CourseViewHolder
         val course = getItem(position)
         with(holder.courseBinding){
//             if (course.isInitial.not()){
//                 ivDelete.makeVisible()
//             }else{
//                 ivDelete.makeGone()
//             }
             tvCourseName.text = course.name
             tvCreditHoursValue.text = "${course.credits} Hours"
         }
     }
    object CourseComparator:DiffUtil.ItemCallback<Course>() {
        override fun areItemsTheSame(oldItem: Course, newItem: Course): Boolean {
          return oldItem.code == newItem.code
                  && oldItem.name == newItem.name
                  && oldItem.prerequisites == newItem.prerequisites
                  && oldItem.credits == newItem.credits
                  && oldItem.description == newItem.description
        }

        override fun areContentsTheSame(oldItem: Course, newItem: Course): Boolean {
            return oldItem.code == newItem.code
                    && oldItem.name == newItem.name
                    && oldItem.prerequisites == newItem.prerequisites
                    && oldItem.credits == newItem.credits
                    && oldItem.description == newItem.description
        }
    }

    inner class CourseViewHolder(val courseBinding:CourseItemLayoutBinding):RecyclerView.ViewHolder(courseBinding.root){
         init {
             itemView.setOnClickListener {
                 val position = adapterPosition
                 if (position != -1){
                     val course = getItem(position)
                     if (course.isInitial.not()) {
                         listener.courseSelected(course.courseId)
                     }
                 }
             }
             courseBinding.ivDelete.setOnClickListener {
                     val position = adapterPosition
                     if (position != -1) {
                         val course = getItem(position)
                         Utils.displaySimpleAlertDialog(context,
                             context.getString(R.string.delete_course),
                             context.getString(R.string.are_you_sure_you_want_to_delete_this_course),
                             context.getString(R.string.delete),context.getString(R.string.cancel),object : CallBacks.SimpleAlertDialog{
                                 override fun positiveButtonClick(text: String) {
                                     listener.courseDeleted(course.courseId)
                                 }
                                 override fun negativeButtonClick() {

                                 }
                             })
                         }
                     }
             }
     }
 }