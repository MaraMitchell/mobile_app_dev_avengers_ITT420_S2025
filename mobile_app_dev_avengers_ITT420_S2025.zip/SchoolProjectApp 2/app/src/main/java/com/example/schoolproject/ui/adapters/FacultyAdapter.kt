package com.example.schoolproject.ui.adapters

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.bookproject.utils.makeGone
import com.example.bookproject.utils.makeVisible
import com.example.schoolproject.R
import com.example.schoolproject.data.model.Faculty
import com.example.schoolproject.utils.CallBacks
import com.example.schoolproject.databinding.CourseItemLayoutBinding
import com.example.schoolproject.databinding.FacultyItemLayoutBinding
import com.example.schoolproject.utils.Utils


class FacultyAdapter(val context:Activity, val listener: CallBacks.FacultyClick):ListAdapter<Faculty,RecyclerView.ViewHolder>(
    FacultyComparator
){
     override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
       return FacultyViewHolder(FacultyItemLayoutBinding.inflate
           (context.layoutInflater,parent,false))
     }
    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        holder as FacultyViewHolder
        val faculty = getItem(position)
        with(holder.facultyBinding) {
            tvName.text = faculty.name
            tvPhoneNumber.text = faculty.telephone
            tvCEmail.text = faculty.email

            tvPhoneNumber.setOnClickListener {
                val context = it.context
                val intent = Intent(Intent.ACTION_DIAL).apply {
                    data = Uri.parse("tel:${faculty.telephone}")
                }
                context.startActivity(intent)
            }

            val photo = if (!faculty.isInitial) {
                faculty.photoPath
            } else {
                faculty.photoPath.toInt()
            }

            try {
                Glide.with(context)
                    .load(photo)
                    .placeholder(R.drawable.img_no_faculty_available)
                    .into(ivBook)
            } catch (_: Exception) {}
        }
    }

    object FacultyComparator:DiffUtil.ItemCallback<Faculty>() {
        override fun areItemsTheSame(oldItem: Faculty, newItem: Faculty): Boolean {
          return oldItem.facultyId == newItem.facultyId
                  && oldItem.name == newItem.name
                  && oldItem.email == newItem.email
                  && oldItem.telephone == newItem.telephone
        }

        override fun areContentsTheSame(oldItem: Faculty, newItem: Faculty): Boolean {
            return oldItem.facultyId == newItem.facultyId
                    && oldItem.name == newItem.name
                    && oldItem.email == newItem.email
                    && oldItem.telephone == newItem.telephone
        }
    }

    inner class FacultyViewHolder(val facultyBinding:FacultyItemLayoutBinding):RecyclerView.ViewHolder(facultyBinding.root){
         init {
             itemView.setOnClickListener {
                 val position = adapterPosition
                 if (position != -1){
                     val faculty = getItem(position)
                     if (faculty.isInitial.not()){
                         listener.facultySelected(faculty.facultyId)
                     }

                 }
             }
             facultyBinding.ivDelete.setOnClickListener {
                     val position = adapterPosition
                     if (position != -1) {
                         val Faculty = getItem(position)
                         Utils.displaySimpleAlertDialog(context,
                             "Delete Faculty Member",
                             "Are you sure you want to delete this faculty member?",
                             context.getString(R.string.delete),context.getString(R.string.cancel),object : CallBacks.SimpleAlertDialog{
                                 override fun positiveButtonClick(text: String) {
                                     listener.facultyDeleted(Faculty.facultyId)
                                 }
                                 override fun negativeButtonClick() {

                                 }
                             })
                         }
                     }
             }
     }
 }