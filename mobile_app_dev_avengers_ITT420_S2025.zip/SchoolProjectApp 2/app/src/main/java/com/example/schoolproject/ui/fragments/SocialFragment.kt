package com.example.schoolproject.ui.fragments

import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.example.bookproject.utils.setSafeClickListener
import com.example.movieapp.view.base.BaseFragment
import com.example.schoolproject.R
import com.example.schoolproject.databinding.FragmentSocialBinding
import com.example.schoolproject.ui.activities.EmailActivity
import com.example.schoolproject.ui.activities.SocialMediaActivity
import com.example.schoolproject.utils.InternetController
import com.example.schoolproject.utils.InternetDialog
import com.example.schoolproject.utils.Social

class SocialFragment : BaseFragment() {
    private lateinit var binding:FragmentSocialBinding
    private lateinit var internetDialog:InternetDialog

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        binding = FragmentSocialBinding.inflate(layoutInflater,container,false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        internetDialog = InternetDialog()
        with(binding){
            facebook.apply {
                ivSocial.setImageResource(R.drawable.facebook)
                tvSocial.text = getString(R.string.facebook)
                root.setSafeClickListener {
                    openSocialMediaActivity(Social.Facebook)
                }
            }
            instagram.apply {
                ivSocial.setImageResource(R.drawable.instagram)
                tvSocial.text = getString(R.string.instagram)
                root.setSafeClickListener {
                    openSocialMediaActivity(Social.Instagram)
                }
            }
            twitter.apply {
                ivSocial.setImageResource(R.drawable.twitter)
                tvSocial.text = getString(R.string.twitter)
                root.setSafeClickListener {
                    openSocialMediaActivity(Social.Twitter)
                }
            }
            fabEmail.setSafeClickListener{
                val emailIntent = Intent(mContext,EmailActivity::class.java)
                startActivity(emailIntent)
            }
        }
    }
    private fun openSocialMediaActivity(social: Social){
        val connectivityManager = mContext.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val internetController = InternetController(connectivityManager)
        if(internetController.isInternetConnected){
            val socialIntent = Intent(mContext,SocialMediaActivity::class.java)
                .putExtra("socialMedia", social.name)
            startActivity(socialIntent)
        }else{
           internetDialog.showConnectToWifiDialog(mContext)
        }
    }
}