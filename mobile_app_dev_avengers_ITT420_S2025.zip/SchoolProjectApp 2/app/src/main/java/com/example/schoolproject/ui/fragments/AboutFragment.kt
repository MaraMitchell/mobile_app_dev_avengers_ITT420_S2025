package com.example.schoolproject.ui.fragments

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import com.example.bookproject.utils.setSafeClickListener
import com.example.movieapp.view.base.BaseFragment
import com.example.schoolproject.R
import com.example.schoolproject.databinding.FragmentAboutBinding

class AboutFragment : BaseFragment() {
    private lateinit var binding: FragmentAboutBinding
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View{
        // Inflate the layout for this fragment
        binding = FragmentAboutBinding.inflate(layoutInflater,container,false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        with(binding){
            tvAbout.text ="To be unconditionally admitted to complete UCC undergraduate programmes, individuals should possess a minimum of five (5) subjects at the GCE or CSEC level (including the mandatory English Language and Mathematics) at grades A, B, C or 1, 2, 3 respectively. A CSEC pass at level 3 must have been obtained since 1998.\n" +
                    "Candidates who have a minimum of 4 CXCs can also apply pending the outstanding CXC subjects or can opt to do UCC replacement courses Core Mathematics, English for Academic Purpose and Fundamentals of Accounting.\n" +
                    "Candidates can opt to apply under the Mature Entry option. To be accepted, applicants must be working for 5 years or more and be at a minimum age of 25 years. Academic qualifications, a detailed resume, a job letter and 3 professional references will be required.\n" +
                    "---\n" +
                    "\n" +
                    "HONOURS PROGRAMME\n" +
                    "Students with 8 CXC/GCE subjects including Mathematics and English Language at Grade 1 may be eligible for a 25% tuition waiver during the first year.\n" +
                    "Terms & Conditions"
            tvVisitThis.setSafeClickListener {
                visitLink("https://ucc.edu.jm")
            }
        }
    }
    private fun visitLink(url: String) {
        val fixedUrl = if (!url.startsWith("https://ucc.edu.jm/apply/undergraduate") && !url.startsWith("https://ucc.edu.jm/apply/undergraduate")) {
            "https://ucc.edu.jm/apply/undergraduate"
        } else {
            url
        }
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(fixedUrl))
        try {
            mContext.startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(mContext, "No application can handle this request.", Toast.LENGTH_SHORT).show()
        }
    }

}