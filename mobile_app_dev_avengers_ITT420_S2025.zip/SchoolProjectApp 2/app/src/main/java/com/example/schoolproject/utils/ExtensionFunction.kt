package com.example.bookproject.utils

import android.view.View

   fun View.makeVisible(){
       this.visibility = View.VISIBLE
   }
    fun View.makeInVisible(){
       this.visibility = View.INVISIBLE
   }
    fun View.makeGone(){
       this.visibility = View.GONE
   }
private const val DEFAULT_DEBOUNCE_INTERVAL = 600L
var lastClickTime = 0L
fun View.setSafeClickListener(interval: Long = DEFAULT_DEBOUNCE_INTERVAL, onSafeClick: (View) -> Unit) {
    setOnClickListener {
        val currentTime = System.currentTimeMillis()
        if (currentTime - lastClickTime > interval) {
            lastClickTime = currentTime
            onSafeClick(it)
        }
    }
}
