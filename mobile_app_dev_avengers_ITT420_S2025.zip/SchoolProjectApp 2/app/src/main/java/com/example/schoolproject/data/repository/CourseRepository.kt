package com.example.schoolproject.data.repository

import android.content.ContentValues
import android.database.sqlite.SQLiteDatabase
import com.example.schoolproject.data.database.DatabaseHelper
import com.example.schoolproject.data.model.Course
import com.example.schoolproject.data.model.Faculty


class CourseRepository(private val dbHelper: DatabaseHelper) {
    fun insert(course: Course): Long = dbHelper.insertCourse(course)
    fun insertAll(courses: List<Course>) = dbHelper.insertAllCourses(courses)
    fun update(course: Course) = dbHelper.updateCourse(course)
    fun deleteById(courseId: Int) = dbHelper.deleteCourseById(courseId)
    fun getCourseById(courseId: Int): Course? = dbHelper.getCourseById(courseId)
    fun getAllCourses(): List<Course> = dbHelper.getAllCourses()
    fun isCourseTableEmpty():Boolean = dbHelper.isCourseTableEmpty()
}

