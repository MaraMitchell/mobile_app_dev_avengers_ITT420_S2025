package com.example.schoolproject.ui.activities

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.bookproject.utils.makeVisible
import com.example.schoolproject.R
import com.example.schoolproject.databinding.ActivitySocialMediaBinding
import com.example.schoolproject.ui.base.BaseActivity
import com.example.schoolproject.utils.Social

class SocialMediaActivity : BaseActivity() {
    private lateinit var binding:ActivitySocialMediaBinding
    private var socialMedia = Social.Facebook
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        binding = ActivitySocialMediaBinding.inflate(layoutInflater)
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        val bundle = intent.extras
        if(bundle != null){
            socialMedia = enumValueOf<Social>(bundle.getString("socialMedia",Social.Facebook.name))
        }
        with(binding){
            toolbarSocial.apply {
                ivBack.makeVisible()
                ivBack.setOnClickListener {
                    handleBackPressed()
                }
                tvTitle.text = socialMedia.name
            }
            socialWebView.settings.javaScriptEnabled = true
            socialWebView.settings.domStorageEnabled = true

            val url = when (socialMedia) {
                Social.Facebook -> "https://www.facebook.com/uccjamaica"
                Social.Twitter -> "https://x.com/uccjamaica"
                Social.Instagram -> "https://www.instagram.com/uccjamaica"
            }

            socialWebView.loadUrl(url)
            }
    }

    override fun handleBackPressed() {
        finish()
    }
}