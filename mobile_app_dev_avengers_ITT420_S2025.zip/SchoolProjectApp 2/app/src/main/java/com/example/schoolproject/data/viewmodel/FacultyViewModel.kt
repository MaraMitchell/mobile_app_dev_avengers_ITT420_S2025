package com.example.schoolproject.data.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.example.schoolproject.data.database.DatabaseHelper
import com.example.schoolproject.data.model.Faculty
import com.example.schoolproject.data.repository.FacultyRepository
import com.example.schoolproject.utils.Utils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class FacultyViewModel(application: Application) : AndroidViewModel(application) {
    private val repository: FacultyRepository
    private val facultyLiveData = MutableLiveData<List<Faculty>>()

    init {
        val dbHelper = DatabaseHelper(application)
        repository = FacultyRepository(dbHelper)
        if (repository.isFacultyTableEmpty()) {
            val initialFacultyList = Utils.getInitialFacultyList()
            insertAll(initialFacultyList)
        } else {
            loadFaculty()
        }
    }

    fun insert(faculty: Faculty) = viewModelScope.launch(Dispatchers.IO) {
        repository.insert(faculty)
        loadFaculty()
    }

    private fun insertAll(faculties: List<Faculty>) = viewModelScope.launch(Dispatchers.IO) {
        repository.insertAll(faculties)
        loadFaculty()
    }

    fun update(faculty: Faculty) = viewModelScope.launch(Dispatchers.IO) {
        repository.update(faculty)
        loadFaculty()
    }

    fun getFacultyById(facultyId: Int): LiveData<Faculty?> {
        val liveData = MutableLiveData<Faculty?>()
        viewModelScope.launch(Dispatchers.IO) {
            liveData.postValue(repository.getFacultyById(facultyId))
        }
        return liveData
    }

    fun deleteById(id: Int) = viewModelScope.launch(Dispatchers.IO) {
        repository.deleteById(id)
        loadFaculty()
    }

    fun getAllFaculty(): LiveData<List<Faculty>> = facultyLiveData

    private fun loadFaculty() {
        viewModelScope.launch(Dispatchers.IO) {
            facultyLiveData.postValue(repository.getAllFaculty())
        }
    }
}

