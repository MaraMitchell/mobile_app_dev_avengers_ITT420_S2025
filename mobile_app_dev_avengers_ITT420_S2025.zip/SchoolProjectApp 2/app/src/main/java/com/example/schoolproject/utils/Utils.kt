package com.example.schoolproject.utils

import android.app.Activity
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.View
import android.view.Window
import android.view.WindowManager
import androidx.appcompat.app.AlertDialog
import com.example.schoolproject.R
import com.example.schoolproject.data.model.Course
import com.example.schoolproject.data.model.Faculty
import com.example.schoolproject.databinding.ExitDialogLayoutBinding

object Utils {
    fun updateStatusBarColor(context: Activity, color: Int) {
        val window: Window = context.window
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        window.statusBarColor = color
    }
    fun getInitialFacultyList():List<Faculty>{
        return listOf(
            Faculty(
                name = "Dr Peter Ndajah, Dean", email = "pnadajah@ucc.edu.jm", telephone = "8769063000",
                photoPath =  R.drawable.staff1.toString(), isInitial = true
            ),
            Faculty(
                name = "Mr Otis Osbourne", email = "itfaculty@ucc.edu.jm", telephone = "8769063000",
                photoPath =  R.drawable.staff2.toString(), isInitial = true
            ),
            Faculty(
                name = "Mr Neil Williams", email = "itlecturer@ucc.edu.jm", telephone = "8769063000",
                photoPath =  R.drawable.staff3.toString(), isInitial = true
            ),
            Faculty(
                name = "Mr Aubryn Smith", email = "mathlecturer@ucc.edu.jm", telephone = "8769063000",
                photoPath =  R.drawable.staff4.toString(), isInitial = true
            ),
            Faculty(
                name = "Ms Karen Wilson", email = "itlecturer2@ucc.edu.jm", telephone = "8769063000",
                photoPath =  R.drawable.staff5.toString(), isInitial = true
            ),
            Faculty(
                name = "Dr Ayanna Frederick", email = "afrederick@faculty.ucc.edu.jm", telephone = "8769063000",
                photoPath =  R.drawable.staff6.toString(), isInitial = true
            ),
            Faculty(
                name = "Dr Sajjad Rizvi", email = "srizvi@faculty.ucc.edu.jm", telephone = "8769063000",
                photoPath =  R.drawable.staff7.toString(), isInitial = true
            )
        )
    }
    fun getInitialCourseList():List<Course>{
        return listOf(
            Course(
                name = "Computer Information Systems", credits = 3.0, description = " ", code = "ITT101", prerequisites = "n/a", isInitial = true
            ),
            Course(
                name = "Programming Techniques", credits = 3.0, description = " ", code = "ITT103", prerequisites = "Computer Information Systems", isInitial = true
            ), Course(
                name = "Computer Data Analysis", credits = 3.0, description = " ", code = "ITT211 ", prerequisites = "n/a", isInitial = true
            ), Course(
                name = "Python Programming", credits = 3.0, description = " " , code = "ITT212 ", prerequisites = "Programming Techniques", isInitial = true
            ), Course(
                name = "Intelligent Systems", credits = 3.0, description = " ", code = "ITT401 ", prerequisites = "Discrete Mathematics II", isInitial = true
            ), Course(
                name = "Calculus I", credits = 3.0, description = " ", code = "MTH103 ", prerequisites = "College Algebra", isInitial = true
            ), Course(
                name = "Database Management Systems", credits = 3.0, description = " ", code = "ITT210 ", prerequisites = "Programming Techniques", isInitial = true
            ), Course(
                name = "System Analysis and Design", credits = 3.0, description = " ", code = "ITT310 ", prerequisites = "Database Management Systems", isInitial = true
            ), Course(
                name = "Technical Writing for Digital Media", credits = 3.0, description = " ", code = "ITT215 ", prerequisites = "Academic Writing I", isInitial = true
            ), Course(
                name = "Discrete Mathematics II", credits = 3.0, description = " ", code = "ITT300", prerequisites = "Discrete Mathematics I", isInitial = true
            ),
        )
    }
    var isInternetDialogShowing = false
    fun displaySimpleAlertDialog(context: Activity, title: String, msg: String, positiveText: String,
                                 negativeText: String, listener: CallBacks.SimpleAlertDialog
    ){
        val binding = ExitDialogLayoutBinding.inflate(context.layoutInflater)
        val dialog = AlertDialog.Builder(context).setView(binding.root).create()
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.setCancelable(false)
//      dialog.window?.setLayout(600,400)
        binding.tvAlertDialogTitle.text = title
        binding.tvAlertDialogMessage.text = msg
        binding.btnPositive.text = positiveText
        binding.btnNegative.text = negativeText
        dialog.apply {
            try {
                if (!this.isShowing && !context.isFinishing && !context.isDestroyed) {
                    this.show()
                }
            } catch (_: Exception) {
            }
        }
        binding.btnPositive.setOnClickListener {
            listener.positiveButtonClick()
            dialog.apply {
                try {
                    if (this.isShowing && !context.isFinishing && !context.isDestroyed) {
                        this.dismiss()
                    }
                } catch (_: Exception) {
                }
            }
        }
        binding.btnNegative.setOnClickListener {
            listener.negativeButtonClick()
            dialog.apply {
                try {
                    if (this.isShowing && !context.isFinishing && !context.isDestroyed) {
                        this.dismiss()
                    }
                } catch (_: Exception) {
                }
            }
        }

    }
}