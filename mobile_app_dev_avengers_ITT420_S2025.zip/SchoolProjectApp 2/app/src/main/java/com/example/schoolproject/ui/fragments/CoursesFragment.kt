package com.example.schoolproject.ui.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.viewModels
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.bookproject.utils.makeGone
import com.example.bookproject.utils.makeVisible
import com.example.movieapp.view.base.BaseFragment
import com.example.schoolproject.R
import com.example.schoolproject.data.model.Course
import com.example.schoolproject.data.viewmodel.CourseViewModel
import com.example.schoolproject.databinding.CourseBottomSheetLayoutBinding
import com.example.schoolproject.databinding.FragmentCoursesBinding
import com.example.schoolproject.ui.adapters.CourseAdapter
import com.example.schoolproject.utils.CallBacks
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog

class CoursesFragment : BaseFragment() {
    private lateinit var binding: FragmentCoursesBinding

    private lateinit var courseAdapter: CourseAdapter
    private val courseViewModel: CourseViewModel by viewModels {
        ViewModelProvider.AndroidViewModelFactory.getInstance(requireActivity().application)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        binding = FragmentCoursesBinding.inflate(layoutInflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        with(binding) {
            //setting course adapter
            courseAdapter = CourseAdapter(mContext, object : CallBacks.CourseClick {
                override fun courseSelected(courseId: Int) {
                    courseViewModel.getCourseById(courseId).observe(viewLifecycleOwner) { course ->
                        course?.let { openButtonSheetDialog(it) }
                    }
                }

                override fun courseDeleted(courseId: Int) {
                    courseViewModel.deleteById(courseId)
                }
            })

            binding.rvCourse.apply {
                layoutManager = LinearLayoutManager(mContext)
                adapter = courseAdapter
            }

            courseViewModel.getAllCourses().observe(viewLifecycleOwner) { courses ->
                progressBar.makeGone()
                if (courses.isEmpty()) {
                    binding.emptyLayout.root.makeVisible()
                    binding.emptyLayout.apply {
                        tvEmpty.text = getString(R.string.no_courses_available)
                        ivEmpty.setImageResource(R.drawable.img_no_courses_available)
                    }
                    binding.rvCourse.makeGone()
                } else {
                    binding.emptyLayout.root.makeGone()
                    binding.rvCourse.makeVisible()
                }
                courseAdapter.submitList(courses)
            }

            binding.btnAddCourse.setOnClickListener { openButtonSheetDialog(null) }
        }
    }

    private fun openButtonSheetDialog(course: Course?) {
        val bottomSheetDialog = BottomSheetDialog(mContext)
        val binding = CourseBottomSheetLayoutBinding.inflate(layoutInflater)
        bottomSheetDialog.setContentView(binding.root)
        with(binding) {
            course?.let { it ->
                tvBottomSheetTitle.text = getString(R.string.update_a_course)
                txtCourseCode.setText(it.code)
                txtPrerequisites.setText(it.prerequisites)
                txtCreditHours.setText(it.credits.toString())
                txtCourseName.setText(it.name)
                txtDescription.setText(it.description)
                btnAddUpdate.text = getString(R.string.update)
            }
            ivClose.setOnClickListener {
                bottomSheetDialog.dismiss()
            }
            btnAddUpdate.setOnClickListener {
                if (txtCourseName.text.isNotBlank() && txtCourseCode.text.isNotBlank() && txtDescription.text.isNotBlank() &&
                    txtCreditHours.text.isNotBlank() && txtPrerequisites.text.isNotBlank()
                ) {
                    val code = txtCourseCode.text.toString().trim()
                    val name = txtCourseName.text.toString().trim()
                    val prerequisites = txtPrerequisites.text.toString().trim()
                    val description = txtDescription.text.toString().trim()
                    val creditHours = txtCreditHours.text.toString().trim()
                    if (course == null) {
                        courseViewModel.insert(
                            Course(
                                code = code,
                                name = name,
                                prerequisites = prerequisites,
                                description = description,
                                credits = creditHours.toDouble()
                            )
                        )
                    } else {
                        courseViewModel.update(
                            Course(
                                courseId = course.courseId,
                                code = code,
                                name = name,
                                prerequisites = prerequisites,
                                description = description,
                                credits = creditHours.toDouble(),
                                isInitial = course.isInitial
                            )
                        )
                    }
                    bottomSheetDialog.dismiss()
                } else {
                    Toast.makeText(mContext, "All fields are required", Toast.LENGTH_SHORT)
                        .show()
                }
            }
        }
        bottomSheetDialog.show()
    }
}