package com.example.schoolproject.ui.activities

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.fragment.app.FragmentActivity
import androidx.viewpager2.adapter.FragmentStateAdapter
import androidx.viewpager2.widget.ViewPager2
import com.example.movieapp.view.base.BaseFragment
import com.example.schoolproject.R
import com.example.schoolproject.databinding.ActivityMainBinding
import com.example.schoolproject.databinding.ExitDialogLayoutBinding
import com.example.schoolproject.ui.base.BaseActivity
import com.example.schoolproject.ui.fragments.AboutFragment
import com.example.schoolproject.ui.fragments.CoursesFragment
import com.example.schoolproject.ui.fragments.FacultyFragment
import com.example.schoolproject.ui.fragments.SocialFragment
import com.google.android.material.bottomsheet.BottomSheetDialog

class MainActivity : BaseActivity() {
    private lateinit var binding: ActivityMainBinding
    lateinit var facultyFragment: FacultyFragment
    lateinit var coursesFragment: CoursesFragment
    lateinit var socialFragment: SocialFragment
    lateinit var aboutFragment: AboutFragment
    private var previousSelectedPosition = 0
    private var previousItemId = R.id.menuFaculty


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        //now tell me what color you like me to change
        //navy blue add text too and logo
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }


//        if(courseViewModel.isCourseTableEmpty()){
//            val initialCourseList = Utils.getInitialCourseList()
//            courseViewModel.insertAll(initialCourseList)
//        }
//        if (facultyViewModel.isFacultyTableEmpty()){
//            val initialFacultyList = Utils.getInitialFacultyList()
//            facultyViewModel.insertAll(initialFacultyList)
//        }
        with(binding) {
            viewPagerMain.isUserInputEnabled = false
            viewPagerMain.adapter = ViewPagerAdapter(this@MainActivity)
            viewPagerMain.setCurrentItem(previousSelectedPosition, false)
            bottomNavigation.selectedItemId = previousItemId
            viewPagerMain.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
                override fun onPageSelected(position: Int) {
                    super.onPageSelected(position)
                    if (previousSelectedPosition != position) {
                        previousSelectedPosition = position
                        when (position) {
                            1 -> {
                                bottomNavigation.selectedItemId = R.id.menuCourses
                                toolbarMain.tvTitle.text = getString(R.string.courses_offered)
                            }

                            2 -> {
                                bottomNavigation.selectedItemId = R.id.menuSocial
                                toolbarMain.tvTitle.text = getString(R.string.social_media)
                            }

                            3 -> {
                                bottomNavigation.selectedItemId = R.id.menuAbout
                                toolbarMain.tvTitle.text =
                                    getString(R.string.admission_requirements)
                            }

                            else -> {
                                bottomNavigation.selectedItemId = R.id.menuFaculty
                                toolbarMain.tvTitle.text = getString(R.string.faculty_list)
                            }
                        }
                    }
                }
            })
            bottomNavigation.setOnItemSelectedListener { item ->
                if (previousItemId != item.itemId) {
                    previousItemId = item.itemId
                    when (item.itemId) {
                        R.id.menuFaculty -> {
                            viewPagerMain.setCurrentItem(0, false)
                        }

                        R.id.menuCourses -> {
                            viewPagerMain.setCurrentItem(1, false)
                        }

                        R.id.menuSocial -> {
                            viewPagerMain.setCurrentItem(2, false)
                        }

                        R.id.menuAbout -> {
                            viewPagerMain.setCurrentItem(3, false)
                        }
                    }
                }
                true
            }
        }

    }

    private fun displayExitDialog() {
        val exitDialog = BottomSheetDialog(mContext)
        val exitBinding = ExitDialogLayoutBinding.inflate(layoutInflater)
        exitDialog.setContentView(exitBinding.root)
        with(exitBinding) {
            tvAlertDialogTitle.text = getString(R.string.exit)
            tvAlertDialogMessage.text = getString(R.string.are_you_sure_you_want_to_exit_the_app)
            btnPositive.text = getString(R.string.exit)
            btnNegative.text = getString(R.string.cancel)
            btnPositive.setOnClickListener {
                finish()
            }
            btnNegative.setOnClickListener {
                exitDialog.dismiss()
            }
        }
        exitDialog.setCanceledOnTouchOutside(false)
        exitDialog.show()
    }

    inner class ViewPagerAdapter(fragmentActivity: FragmentActivity) :
        FragmentStateAdapter(fragmentActivity) {
        override fun getItemCount(): Int {
            return 4
        }

        override fun createFragment(position: Int): BaseFragment {
            when (position) {
                1 -> {
                    coursesFragment = CoursesFragment()
                    return coursesFragment
                }

                2 -> {
                    socialFragment = SocialFragment()
                    return socialFragment
                }

                3 -> {
                    aboutFragment = AboutFragment()
                    return aboutFragment
                }

                else -> {
                    facultyFragment = FacultyFragment()
                    return facultyFragment
                }
            }
        }
    }

    override fun handleBackPressed() {
        if (binding.viewPagerMain.currentItem == 0) {
            finish()
        } else {
            displayExitDialog()
        }
    }
}