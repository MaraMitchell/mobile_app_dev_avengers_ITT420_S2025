package com.example.schoolproject.data.model

data class Course(
    val courseId: Int = 0,
    val code: String,
    val name: String,
    val credits: Double,
    val prerequisites: String,
    val description: String,
    var isInitial:Boolean = false
)
