package com.example.schoolproject.utils

class CallBacks{
    interface SimpleAlertDialog {
        fun positiveButtonClick(text:String = "")
        fun negativeButtonClick()
    }
    interface CourseClick{
        fun courseSelected(courseId:Int)
        fun courseDeleted(courseId:Int)
    }
    interface FacultyClick{
        fun facultySelected(facultyId:Int)
        fun facultyDeleted(facultyId:Int)
    }
}