package com.example.schoolproject.ui.activities

import android.content.Intent
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.bookproject.utils.setSafeClickListener
import com.example.schoolproject.R
import com.example.schoolproject.databinding.ActivitySplahBinding
import com.example.schoolproject.ui.base.BaseActivity

class SplashActivity : BaseActivity() {
    lateinit var binding:ActivitySplahBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySplahBinding.inflate(layoutInflater)
        enableEdgeToEdge()
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        with(binding){
           ivSplash.setImageResource(R.drawable.avengers)
            tvSplash.text = "UCC APP by " +
                    "Avengers"
            btnSplash.setSafeClickListener {
               val homeIntent = Intent(mContext, MainActivity::class.java)
                startActivity(homeIntent)
                finish()
            }
        }

    }

    override fun handleBackPressed() {
        finish()
    }
}