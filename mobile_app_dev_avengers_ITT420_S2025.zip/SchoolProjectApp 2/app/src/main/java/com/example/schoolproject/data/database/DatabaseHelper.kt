package com.example.schoolproject.data.database

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import com.example.schoolproject.data.model.Course
import com.example.schoolproject.data.model.Faculty

class DatabaseHelper(context: Context) :
    SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        private const val DATABASE_NAME = "app_database.db"
        private const val DATABASE_VERSION = 2 // Incremented version

        // Course table
        private const val TABLE_COURSE = "course_table"
        private const val COLUMN_COURSE_ID = "course_id"
        private const val COLUMN_CODE = "code"
        private const val COLUMN_NAME = "name"
        private const val COLUMN_CREDITS = "credits"
        private const val COLUMN_PREREQUISITES = "prerequisites"
        private const val COLUMN_DESCRIPTION = "description"
        private const val COLUMN_IS_INITIAL = "is_initial"

        // Faculty table
        private const val TABLE_FACULTY = "faculty_table"
        private const val COLUMN_FACULTY_ID = "faculty_id"
        private const val COLUMN_FACULTY_NAME = "name"
        private const val COLUMN_EMAIL = "email"
        private const val COLUMN_PHOTO = "photo_path"
        private const val COLUMN_TELEPHONE = "telephone"
    }

    override fun onCreate(db: SQLiteDatabase) {
        val createCourseTable = """
            CREATE TABLE $TABLE_COURSE (
                $COLUMN_COURSE_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COLUMN_CODE TEXT,
                $COLUMN_NAME TEXT NOT NULL,
                $COLUMN_CREDITS DOUBLE NOT NULL,
                $COLUMN_PREREQUISITES TEXT,
                $COLUMN_DESCRIPTION TEXT,
                $COLUMN_IS_INITIAL INTEGER DEFAULT 0
            )
        """.trimIndent()

        val createFacultyTable = """
            CREATE TABLE $TABLE_FACULTY (
                $COLUMN_FACULTY_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COLUMN_FACULTY_NAME TEXT NOT NULL,
                $COLUMN_EMAIL TEXT NOT NULL,
                $COLUMN_PHOTO TEXT,
                $COLUMN_TELEPHONE TEXT,
                $COLUMN_IS_INITIAL INTEGER DEFAULT 0
            )
        """.trimIndent()

        db.execSQL(createCourseTable)
        db.execSQL(createFacultyTable)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS $TABLE_COURSE")
        db.execSQL("DROP TABLE IF EXISTS $TABLE_FACULTY")
        onCreate(db)
    }

    // Course
    fun insertCourse(course: Course): Long {
        val db = writableDatabase
        val values = ContentValues().apply {
            put(COLUMN_CODE, course.code)
            put(COLUMN_NAME, course.name)
            put(COLUMN_CREDITS, course.credits)
            put(COLUMN_PREREQUISITES, course.prerequisites)
            put(COLUMN_DESCRIPTION, course.description)
            put(COLUMN_IS_INITIAL, if (course.isInitial) 1 else 0)
        }
        return db.insertWithOnConflict(TABLE_COURSE, null, values, SQLiteDatabase.CONFLICT_REPLACE)
            .also { db.close() }
    }

    fun insertAllCourses(courses: List<Course>) {
        val db = writableDatabase
        db.beginTransaction()
        try {
            for (course in courses) {
                val values = ContentValues().apply {
                    put(COLUMN_CODE, course.code)
                    put(COLUMN_NAME, course.name)
                    put(COLUMN_CREDITS, course.credits)
                    put(COLUMN_PREREQUISITES, course.prerequisites)
                    put(COLUMN_DESCRIPTION, course.description)
                    put(COLUMN_IS_INITIAL, if (course.isInitial) 1 else 0)
                }
                db.insertWithOnConflict(TABLE_COURSE, null, values, SQLiteDatabase.CONFLICT_REPLACE)
            }
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
            db.close()
        }
    }


    fun updateCourse(course: Course): Int {
        val db = writableDatabase
        val values = ContentValues().apply {
            put(COLUMN_CODE, course.code)
            put(COLUMN_NAME, course.name)
            put(COLUMN_CREDITS, course.credits)
            put(COLUMN_PREREQUISITES, course.prerequisites)
            put(COLUMN_DESCRIPTION, course.description)
            put(COLUMN_IS_INITIAL, if (course.isInitial) 1 else 0)
        }
        val result = db.update(
            TABLE_COURSE,
            values,
            "$COLUMN_COURSE_ID=?",
            arrayOf(course.courseId.toString())
        )
        db.close()
        return result
    }

    fun deleteCourseById(courseId: Int) {
        val db = writableDatabase
        db.delete(TABLE_COURSE, "$COLUMN_COURSE_ID=?", arrayOf(courseId.toString()))
        db.close()
    }

    fun getCourseById(courseId: Int): Course? {
        val db = readableDatabase
        val cursor = db.query(
            TABLE_COURSE,
            null,
            "$COLUMN_COURSE_ID=?",
            arrayOf(courseId.toString()),
            null,
            null,
            null
        )
        val course = if (cursor.moveToFirst()) {
            Course(
                courseId = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_COURSE_ID)),
                code = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_CODE)),
                name = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_NAME)),
                credits = cursor.getDouble(cursor.getColumnIndexOrThrow(COLUMN_CREDITS)),
                prerequisites = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_PREREQUISITES)),
                description = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_DESCRIPTION)),
                isInitial = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_IS_INITIAL)) == 1
            )
        } else null
        cursor.close()
        db.close()
        return course
    }

    fun getAllCourses(): List<Course> {
        val db = readableDatabase
        val list = mutableListOf<Course>()
        val cursor = db.rawQuery("SELECT * FROM $TABLE_COURSE", null)
        if (cursor.moveToFirst()) {
            do {
                list.add(
                    Course(
                        courseId = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_COURSE_ID)),
                        code = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_CODE)),
                        name = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_NAME)),
                        credits = cursor.getDouble(cursor.getColumnIndexOrThrow(COLUMN_CREDITS)),
                        prerequisites = cursor.getString(
                            cursor.getColumnIndexOrThrow(
                                COLUMN_PREREQUISITES
                            )
                        ),
                        description = cursor.getString(
                            cursor.getColumnIndexOrThrow(
                                COLUMN_DESCRIPTION
                            )
                        ),
                        isInitial = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_IS_INITIAL)) == 1
                    )
                )
            } while (cursor.moveToNext())
        }
        cursor.close()
        db.close()
        return list
    }

    // Faculty
    fun insertFaculty(faculty: Faculty): Long {
        val db = writableDatabase
        val values = ContentValues().apply {
            put(COLUMN_FACULTY_NAME, faculty.name)
            put(COLUMN_EMAIL, faculty.email)
            put(COLUMN_PHOTO, faculty.photoPath)
            put(COLUMN_TELEPHONE, faculty.telephone)
            put(COLUMN_IS_INITIAL, if (faculty.isInitial) 1 else 0)
        }
        return db.insertWithOnConflict(TABLE_FACULTY, null, values, SQLiteDatabase.CONFLICT_REPLACE)
            .also { db.close() }
    }

    fun insertAllFaculty(facultyList: List<Faculty>) {
        val db = writableDatabase
        db.beginTransaction()
        try {
            for (faculty in facultyList) {
                val values = ContentValues().apply {
                    put(COLUMN_FACULTY_NAME, faculty.name)
                    put(COLUMN_EMAIL, faculty.email)
                    put(COLUMN_PHOTO, faculty.photoPath)
                    put(COLUMN_TELEPHONE, faculty.telephone)
                    put(COLUMN_IS_INITIAL, if (faculty.isInitial) 1 else 0)
                }
                db.insertWithOnConflict(TABLE_FACULTY, null, values, SQLiteDatabase.CONFLICT_REPLACE)
            }
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
            db.close()
        }
    }


    fun updateFaculty(faculty: Faculty): Int {
        val db = writableDatabase
        val values = ContentValues().apply {
            put(COLUMN_FACULTY_NAME, faculty.name)
            put(COLUMN_EMAIL, faculty.email)
            put(COLUMN_PHOTO, faculty.photoPath)
            put(COLUMN_TELEPHONE, faculty.telephone)
            put(COLUMN_IS_INITIAL, if (faculty.isInitial) 1 else 0)
        }
        val result = db.update(
            TABLE_FACULTY,
            values,
            "$COLUMN_FACULTY_ID=?",
            arrayOf(faculty.facultyId.toString())
        )
        db.close()
        return result
    }

    fun deleteFaculty(facultyId: Int) {
        val db = writableDatabase
        db.delete(TABLE_FACULTY, "$COLUMN_FACULTY_ID=?", arrayOf(facultyId.toString()))
        db.close()
    }

    fun getFacultyById(facultyId: Int): Faculty? {
        val db = readableDatabase
        val cursor = db.query(
            TABLE_FACULTY,
            null,
            "$COLUMN_FACULTY_ID=?",
            arrayOf(facultyId.toString()),
            null,
            null,
            null
        )
        val faculty = if (cursor.moveToFirst()) {
            Faculty(
                facultyId = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_FACULTY_ID)),
                name = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_FACULTY_NAME)),
                email = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_EMAIL)),
                photoPath = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_PHOTO)),
                telephone = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_TELEPHONE)),
                isInitial = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_IS_INITIAL)) == 1
            )
        } else null
        cursor.close()
        db.close()
        return faculty
    }

    fun getAllFaculty(): List<Faculty> {
        val db = readableDatabase
        val list = mutableListOf<Faculty>()
        val cursor = db.rawQuery("SELECT * FROM $TABLE_FACULTY", null)
        if (cursor.moveToFirst()) {
            do {
                list.add(
                    Faculty(
                        facultyId = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_FACULTY_ID)),
                        name = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_FACULTY_NAME)),
                        email = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_EMAIL)),
                        photoPath = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_PHOTO)),
                        telephone = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_TELEPHONE)),
                        isInitial = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_IS_INITIAL)) == 1
                    )
                )
            } while (cursor.moveToNext())
        }
        cursor.close()
        db.close()
        return list
    }

    fun isFacultyTableEmpty(): Boolean {
        val db = readableDatabase
        val cursor = db.rawQuery("SELECT COUNT(*) FROM $TABLE_FACULTY", null)
        val isEmpty = cursor.moveToFirst() && cursor.getInt(0) == 0
        cursor.close()
        db.close()
        return isEmpty
    }
    fun isCourseTableEmpty(): Boolean {
        val db = readableDatabase
        val cursor = db.rawQuery("SELECT COUNT(*) FROM $TABLE_COURSE", null)
        val isEmpty = cursor.moveToFirst() && cursor.getInt(0) == 0
        cursor.close()
        db.close()
        return isEmpty
    }
}
