package com.example.schoolproject.data.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.example.schoolproject.data.database.DatabaseHelper
import com.example.schoolproject.data.model.Course
import com.example.schoolproject.data.repository.CourseRepository
import com.example.schoolproject.utils.Utils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class CourseViewModel(application: Application) : AndroidViewModel(application) {
    private val repository: CourseRepository
    private val coursesLiveData = MutableLiveData<List<Course>>()

    init {
        val dbHelper = DatabaseHelper(application)
        repository = CourseRepository(dbHelper)
        if (repository.isCourseTableEmpty()) {
            val initialCourseList = Utils.getInitialCourseList()
            insertAll(initialCourseList)
        } else {
            loadCourses()
        }
    }

    fun insert(course: Course) = viewModelScope.launch(Dispatchers.IO) {
        repository.insert(course)
        loadCourses()
    }

    private fun insertAll(courses: List<Course>) = viewModelScope.launch(Dispatchers.IO) {
        repository.insertAll(courses)
        loadCourses()
    }

    fun update(course: Course) = viewModelScope.launch(Dispatchers.IO) {
        repository.update(course)
        loadCourses()
    }

    fun deleteById(courseId: Int) = viewModelScope.launch(Dispatchers.IO) {
        repository.deleteById(courseId)
        loadCourses()
    }

    fun getCourseById(courseId: Int): LiveData<Course?> {
        val liveData = MutableLiveData<Course?>()
        viewModelScope.launch(Dispatchers.IO) {
            liveData.postValue(repository.getCourseById(courseId))
        }
        return liveData
    }

    fun getAllCourses(): LiveData<List<Course>> = coursesLiveData

    private fun loadCourses() {
        viewModelScope.launch(Dispatchers.IO) {
            coursesLiveData.postValue(repository.getAllCourses())
        }
    }
}