package com.example.schoolproject.data.model

data class Faculty(
    val facultyId: Int = 0,
    val name: String,
    val email: String,
    val photoPath: String,
    val telephone: String,
    var isInitial:Boolean = false
)
