package com.example.schoolproject.ui.activities

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.os.Bundle
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.bookproject.utils.makeVisible
import com.example.schoolproject.R
import com.example.schoolproject.databinding.ActivityEmailBinding
import com.example.schoolproject.ui.base.BaseActivity
import com.example.schoolproject.utils.CallBacks
import com.example.schoolproject.utils.InternetController
import com.example.schoolproject.utils.InternetDialog
import com.example.schoolproject.utils.Utils

class EmailActivity : BaseActivity() {
    private lateinit var binding:ActivityEmailBinding
    private lateinit var internetDialog: InternetDialog
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        binding = ActivityEmailBinding.inflate(layoutInflater)
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        internetDialog = InternetDialog()
        with(binding){
            toolbarEmail.apply {
                ivBack.makeVisible()
                ivBack.setOnClickListener {
                    handleBackPressed()
                }
                tvTitle.text = getString(R.string.send_email)
            }
            btnSendEmail.setOnClickListener {
                val subject = txtSubject.text.toString().trim()
                val content = txtContent.text.toString().trim()

                if (subject.isEmpty()) {
                    txtSubject.error = "Please enter a subject"
                    txtSubject.requestFocus()
                    return@setOnClickListener
                }

                if (content.isEmpty()) {
                    txtContent.error = "Please enter email content"
                    txtContent.requestFocus()
                    return@setOnClickListener
                }
                val connectivityManager = mContext.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
                val internetController = InternetController(connectivityManager)
                if(internetController.isInternetConnected) {
                    sendEmail(subject, content)
                }else{
                    internetDialog.showConnectToWifiDialog(mContext)
                }
            }
        }
    }
    private fun sendEmail(subject: String, content: String) {
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "message/rfc822"
            putExtra(Intent.EXTRA_EMAIL, arrayOf("ithod@ucc.edu.jm"))
            putExtra(Intent.EXTRA_SUBJECT, subject)
            putExtra(Intent.EXTRA_TEXT, content)
        }

        try {
            startActivity(Intent.createChooser(intent, "Choose an Email client:"))
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, "No email clients installed.", Toast.LENGTH_SHORT).show()
        }
    }

    override fun handleBackPressed() {
        if(binding.txtSubject.text.isBlank() && binding.txtContent.text.isBlank()){
            finish()
        }else{
            displayDiscardEmailDialog()
        }
    }
    private fun displayDiscardEmailDialog(){
        Utils.displaySimpleAlertDialog(mContext, "Discard this email?",
            "Are you sure you wan to discard this email?", "Discard", "Cancel",
            object :CallBacks.SimpleAlertDialog{
                override fun positiveButtonClick(text: String) {
                    finish()
                }

                override fun negativeButtonClick() {

                }

            })
    }
}