package com.example.schoolproject.utils

enum class Social {
    Facebook, Twitter, Instagram
}